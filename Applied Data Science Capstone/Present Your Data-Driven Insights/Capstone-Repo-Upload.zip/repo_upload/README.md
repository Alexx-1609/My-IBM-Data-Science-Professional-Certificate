# SpaceX Falcon 9 First-Stage Landing Prediction

**IBM Data Science Professional Certificate — Applied Data Science Capstone**
Author: Utkarsh Raj

## Project Overview

This project analyzes historical SpaceX Falcon 9 launch data to identify the factors that
influence successful first-stage booster landings, and builds a machine learning model to
predict landing outcome. Since SpaceX offers much lower launch costs than competitors by
reusing the first stage, predicting landing success can help estimate the cost of a launch.

## Contents

| File | Description |
|---|---|
| `jupyter-labs-spacex-data-collection-api.ipynb` | Collects launch data from the SpaceX REST API |
| `Webscraping.ipynb` | Scrapes historical launch records from Wikipedia |
| `Data_Wrangling.ipynb` | Cleans data and engineers the binary landing-outcome label |
| `EDA_with_SQL.ipynb` | Exploratory data analysis using SQL queries |
| `EDA_with_Data_Visualization.ipynb` | Exploratory data analysis using Matplotlib/Seaborn |
| `Interactive_Visual_Analytics_with_Folium.ipynb` | Geospatial analysis of launch sites with Folium |
| `spacex_dash_app.py` | Interactive Plotly Dash dashboard |
| `Machine_Learning_Prediction.ipynb` | Classification models (Logistic Regression, SVM, Decision Tree, KNN) with GridSearchCV tuning |

## Data Files

- `Spacex.csv` — web-scraped launch records
- `dataset_part_1.csv`, `dataset_part_2.csv`, `dataset_part_3.csv` — progressively cleaned/engineered datasets
- `spacex_launch_dash.csv`, `spacex_launch_geo.csv`, `spacex_web_scraped.csv`, `train.csv` — supporting datasets for the dashboard, map, and modelling notebooks

## Key Results

- Four tuned classifiers (Logistic Regression, SVM, Decision Tree, KNN) all achieved **83.3% test accuracy**
- The Decision Tree classifier had the strongest cross-validated training accuracy at **87.7%**
- Newer booster versions, orbit type, and launch site were all meaningfully associated with landing success

## Tools & Libraries

Python, Pandas, NumPy, SQLite, BeautifulSoup, Matplotlib, Seaborn, Folium, Plotly/Plotly Dash, scikit-learn
